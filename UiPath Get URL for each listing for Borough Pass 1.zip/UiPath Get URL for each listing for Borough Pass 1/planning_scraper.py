import pandas as pd
import time
from random import random

import requests
from bs4 import BeautifulSoup

#import csv of links
links = pd.read_csv('Planning Data.csv', header=None, names=['Title','Url'], encoding='ISO-8859-1')
links = links.tail(6500)
links = links.reset_index()

#Create header of scraper
user_agent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.136 Safari/536.36 Edge/12.246'
headers = {'User-Agent': user_agent}

#tabs
tabs = ['summary','details','dates']

#create dataframe to save the data
column_names = ["Reference", "Application Received", "Address", "Proposal", "Status", "Authority Decision",
                "Authority Decision Date", "PAC Decision", "PAC Decision Date", "Application Type", "Authority",
                "Ward", "Applicant Name", "Environmental Assessment Requested", "Application Received Date",
                "Application Validated Date", "Latest Neighbour Consultation Date", 
                "Neighbour Consultation Expiry Date", "Standard Consultation Date", 
                "Standard Consultation Expiry Date", "Date Last Advertised", "Latest Advertisement Expiry Date", 
                "Statutory Expiry Date", "Decision Issued Date", "Permission Expiry Date", 
                "Environmental Impact Assessment Received", "Temporary Permission Expiry Date", "Date Withdrawn"]
data = pd.DataFrame(columns = column_names)

#loop through list of links
for i in range(len(links)):
    #add pause
    time.sleep(random()*7.5)
    
    #construct development url
    main_url = "https://publicaccess.aberdeencity.gov.uk/" + links['Url'][i]
    main_url = main_url[:-7]
    
    #add new row to dataframe
    data = data.append(pd.Series(name=i))
    
    #loop through tabs
    for j in tabs:
        #add pause
        time.sleep(random()*2.5)
        
        #update url
        url = main_url + j
        
        #create soup
        result = requests.get(url, headers=headers)
        soup = BeautifulSoup(result.text, 'html.parser')
        
        #get data
        table = soup.find_all("tr")
        for item in table:
            field = item.th.text
            field = field.strip()
            value = item.td.text
            value = value.strip()
            
            #update dataframe with value
            data[field][i] = value
            
            
#save data to csv
data.to_csv('Planning Data3.csv')